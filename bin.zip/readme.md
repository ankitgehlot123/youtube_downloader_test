## Youtube Downloader Web App
-----------------------------
Working youtube downloader app. Uses [youtube-dl](https://rg3.github.io/youtube-dl/) and [node-youtube-dl](https://github.com/fent/node-youtube-dl) wrapper.

#### How to run
1. Make sure you've have nodejs installed on your system.
2. Then do `npm install` and `npm start`. It will automatically download *youtube-dl* if it's not exist on your system.

Tutorial found at: https://hackprogramming.com/how-to-create-your-own-youtube-downloader-web-app-using-youtube-dl-in-expressjs/
